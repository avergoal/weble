<?php
class users{
	function auth($data)
	{
		return '{"id":"35","username":"evgeniy","avatar":"https://static.weble.club/users/0/1/c/3/01c3e55123369cc86e747f791fbe566e35.jpg","sex":"0","web":"","phone":"","email":"severomorets@mail.ru","info":"","posts":"9","subscribers":"3","subscriptions":"1","settings":{"nsfw":"0","lang":"ru","feed":"0"},"success":true,"notifications":"1","pm":"-1","is_moderator":false,"logged_in":true}';
	}
}
class channels{
	function categories()
	{
		return '[{"cat_id":"1","cat_title":"Политика","cat_avatar":"http://weble.club//media/icons/politic.svg","cat_nsfw":"0","cat_translate":{"en":"Politics","de":"Politik","es":"Política","fr":"Politique","it":"Politica","ru":"Политика"}},{"cat_id":"2","cat_title":"Авто","cat_avatar":"http://weble.club//media/icons/auto.svg","cat_nsfw":"0","cat_translate":{"en":"Auto","de":"Auto","es":"Auto","fr":"Auto","it":"Auto","ru":"Авто"}},{"cat_id":"3","cat_title":"Знаменитости","cat_avatar":"http://weble.club//media/icons/celebrity.svg","cat_nsfw":"0","cat_translate":{"en":"Celebrities","de":"Prominenz","es":"Celebridades","fr":"Célébrités","it":"Celebrità","ru":"Знаменитости"}},{"cat_id":"5","cat_title":"Разное","cat_avatar":"http://weble.club//media/icons/other.svg","cat_nsfw":"0","cat_translate":{"en":"Other","de":"Verschiedenes","es":"Vario","fr":"Divers","it":"Varia","ru":"Разное"}},{"cat_id":"6","cat_title":"Игры","cat_avatar":"http://weble.club//media/icons/games.svg","cat_nsfw":"0","cat_translate":{"en":"Games","de":"Spiel","es":"Juegos","fr":"Jeux","it":"Giochi","ru":"Игры"}},{"cat_id":"7","cat_title":"Спорт","cat_avatar":"http://weble.club//media/icons/sport.svg","cat_nsfw":"0","cat_translate":{"en":"Sport","de":"Sport","es":"Deporte","fr":"Sport","it":"Sport","ru":"Спорт"}},{"cat_id":"8","cat_title":"Путешествия","cat_avatar":"http://weble.club//media/icons/travel.svg","cat_nsfw":"0","cat_translate":{"en":"Travels","de":"Reisen","es":"Viajes","fr":"Voyages","it":"Viaggi","ru":"Путешествия"}},{"cat_id":"9","cat_title":"Юмор","cat_avatar":"http://weble.club//media/icons/humor.svg","cat_nsfw":"0","cat_translate":{"en":"Humor","de":"Humor","es":"Humor","fr":"Humour","it":"Umorismo","ru":"Юмор"}},{"cat_id":"10","cat_title":"Кино","cat_avatar":"http://weble.club//media/icons/cinema.svg","cat_nsfw":"0","cat_translate":{"en":"Cinema","de":"Kino","es":"Cine","fr":"Cinéma","it":"Cinema","ru":"Кино"}},{"cat_id":"11","cat_title":"Музыка","cat_avatar":"http://weble.club//media/icons/music.svg","cat_nsfw":"0","cat_translate":{"en":"Music","de":"Musik","es":"Músico","fr":"Musique","it":"Musica","ru":"Музыка"}},{"cat_id":"12","cat_title":"Еда","cat_avatar":"http://weble.club//media/icons/food.svg","cat_nsfw":"0","cat_translate":{"en":"Food","de":"Essen","es":"Comida","fr":"Repas","it":"Pasto","ru":"Еда"}}]';
	}
}
class feed{
	function popular()
	{
		return '[
		{"id":"4490",
		"title":"Top Gear on Twitter",
		"tags":[],
		"spoiler":"0",
		"user_id":"7",
		"nsfw":"0",
		"created_at":"1581943202",
		"text":"https://twitter.com/BBC_TopGear/status/1229135959440134145",
		"avatar":"https://static.weble.club/media/9/4/7/3/94739feaba402e43790f94a2027c8531_7.jpeg",
		"comments":"0",
		"rating":1,
		"attachments":null,
		"link":{
		    "type":"url","url":"https://twitter.com/BBC_TopGear/status/1229135959440134145",
		    "name":"Top Gear on Twitter",
		    "description":"“Stood on the platform at rush hour waiting for a train... #TopGear https://t.co/ejzzVkkEo7”",
		    "preview":"https://static.weble.club/media/e/5/5/d/e55d2143c06d1f38fe156594a6376267_7.jpeg"
		    },
		 "share_url":"http://www.weble.club/p/4490",
		 "deleted":false,
		 "channel":{
		    "id":"2",
		    "name":"TopGear",
		    "nsfw":"0",
		    "avatar":"https://static.weble.club/channels/d/4/b/c/d4bc33e3f116fe6587f1374efd137aba_7.jpg"
		    },
		 "user":{
		    "username":"Jasmin",
		    "id":"7",
		    "avatar":"https://static.weble.club/users/c/7/2/6/c72615ed798e6062a6238c98a4af86967.jpg"
		    },
		 "myrating":0}
		 ]';

	}
}




    function proxy_function($data){
        //объявляешь где-нибудь все классы
         $users= new users();
         $channels= new channels();
         $feed= new feed();
        //парсишь класс/метод из запроса
         $class = explode('.',$data['method'])[0];
         $method = explode('.',$data['method'])[1];
            //скармливаешь запрос
         $res = $$class->$method($data);
         //отправляешь в ноду результат
        return $res;
    }


?>
