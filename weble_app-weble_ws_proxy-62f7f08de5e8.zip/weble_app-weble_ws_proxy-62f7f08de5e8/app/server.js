const https     = require('https');
const fs    = require('fs');
const uuidv1 = require('uuid/v1');
const events = require('events');

io = {}
global.USERS  = {};
global.amqp = new events.EventEmitter()
global.amqpEmitters = {
    MainPost:true,
    HotListPost:true,
}
module.exports = class Server{
    constructor(data) {
        let cert       = '../crt/cert.crt';
        let privateKey = '../crt/key.key';
        // let cert       = '/etc/letsencrypt/live/wms-dev.ru/fullchain.pem';
        // const privateKey = './crt/key.key';
        // let privateKey = '/etc/letsencrypt/live/wms-dev.ru/privkey.pem';
        if (!fs.existsSync(cert)) {
            cert       = './crt/cert.crt';
        }
        if (!fs.existsSync(privateKey)) {
            privateKey = './crt/key.key';
        }
        const options = {
            key: fs.readFileSync(privateKey, 'utf8'),
            cert: fs.readFileSync(cert, 'utf8')
        };
        const server = new https.createServer(options);
        https.createServer(options, httpServer).listen(global.config['http_port']||8001);
        global.controllers = {}
        global.controllers.users = require('./controllers/users');
        global.controllers.pm = require('./controllers/pm');
        server.listen(global.config['ws_port']||7005,"0.0.0.0");
        require('./amqp')();
        io = require('socket.io')(server);
        io.on('connection', onConnect);
        console.log('ssssssssss')
    }
};
onConnect = (ws, response, auth)=>{
    console.log('connect user')
    ws.SESSION_ID  = uuidv1();
    ws.on('message', (require('./request')));
    ws.on('disconnect', onClose);
};
getOnlineIds = ()=>{
    return Object.keys(global.USERS);
}
onMessage = function(message){
    console.log('IN MESSAGE',message)


    // let t = (message);

};
onClose = function(){
    if (this.profile&&this.profile.id){
        if (global.USERS[this.profile.id]){
            let ws = global.USERS[this.profile.id].ws.findIndex(ws=>ws.SESSION_ID===this.SESSION_ID)
            global.USERS[this.profile.id].ws.splice(ws, 1);
            if ( global.USERS[this.profile.id].ws.length===0){
                delete global.USERS[this.profile.id];
            }

        }


        io.send(JSON.stringify({method:"worker/EVENT/UserDisconnect",data:{id:this.profile.id}}))

    }

    console.log('USER CLOSE',this.profile?this.profile.id:null)
};

function httpServer(request, response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    response.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    response.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, x-csrf-token, x-access-token, X-HTTP-Method-Override, Content-Type, contenttype, Accept');
    response.setHeader('Access-Control-Allow-Credentials', true);
    if (request.method == 'OPTIONS') {
        response.setHeader('Access-Control-Allow-Origin', request.headers.origin);
        response.statusCode = 200;
        response.end();
    }

    if (request.url == '/crossdomain.xml') {
        response.statusCode = 200;
        response.setHeader('Content-Type', 'text/xml');
        response.body = `<cross-domain-policy>
            <allow-access-from domain="*" to-ports="*"/>
            </cross-domain-policy>`;
        response.end();
    }
    if (request.method == 'POST'){
        let body = '';
        request.on('data', function (data) {
            body += data;
            if (body.length > 1e6) request.connection.destroy();
        });
    }
}
