var amqp = require('amqplib/callback_api');
module.exports = function (){

        amqp.connect('amqp://admin:31709d287a1c612a8df434cf1539ccd6b38d1cf3@185.45.144.84:5672', function(error0, connection) {
            if (error0) {
                throw error0;
            }
            connection.createChannel(function(error1, channel) {
                if (error1) {
                    throw error1;
                }
                Object.keys(global.amqpEmitters).map(key=>{
                    channel.assertQueue(key, {
                        durable: false
                    });
                    channel.consume(key, function(msg) {
                        global.amqp.emit(key,msg.content.toString())
                    }, {
                        noAck: true
                    });
                })

            });
        });
}
global.amqp.on('MainPost',d=>{
    console.log("MainPost",d)
    let data = JSON.parse(d)

    data.ids.map(id=>{
        if (global.USERS[id]){
            global.USERS[id].ws.map(ws=>{
                ws.send(JSON.stringify(
                    {
                        method:"worker/EVENT/MainPost",
                        data:data.data
                    }
                ))
            })

        }
    })

})
global.amqp.on('HotListPost',d=>{
    console.log("HotListPost",d)
    let data = JSON.parse(d)
    io.send(JSON.stringify({method:"worker/EVENT/HotListPost",data:data.data}))
})
