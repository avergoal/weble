module.exports.send = function(ws,data){
    if (data.response.data.text=='post'){
        ws.send(JSON.stringify(
            {
                method:"worker/EVENT/MainPost",
                data:{}
            }
        ))
    }
    if (data.response.data.text=='post'){
        ws.send(JSON.stringify(
            {
                method:"worker/EVENT/HotListPost",
                data:{}
            }
        ))
    }
    if (global.USERS[data.data['chat_id']]){
        for (var i = 0; i < global.USERS[data.data['chat_id']].ws.length; i++) {

            global.USERS[data.data['chat_id']].ws[i].send(JSON.stringify(
                {
                    method:"worker/EVENT/IncomingMessage",
                    data:{
                        chat_id:ws.profile.id,
                        // message:data.response
                        message:{
                            created_at: data.response.data.created_at,
                            id: data.response.data.id,
                            status: data.response.data.status,
                            text: data.response.data.text,
                            user:data.response.data.user
                        }
                    }
                }
            ))
        }


    }
}
module.exports._send = function(ws,data){
    if (global.USERS[data.data['chat_id']]){
        data.data.status = 1
    }
    return data
}

