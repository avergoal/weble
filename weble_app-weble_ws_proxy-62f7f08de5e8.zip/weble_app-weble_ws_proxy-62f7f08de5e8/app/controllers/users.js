module.exports.auth = function(ws,data){
    console.log('user auth',data.response.id,data.data.device)
    // console.log(data)
        data.online = getOnlineIds()
    if (global.USERS[data.response.id]){
        if (data.data.device&&data.data.device== global.USERS[data.response.id].device){
            console.log('IS AUTH')
        }else{
            global.USERS[data.response.id].ws.push(ws)
        }

    }else{
        data.response
        global.USERS[data.response.id] = {
            profile:data.response,
            device:data.data.device,
            ws:[ws]
        }
    }

        ws.profile = data.response
        io.send(JSON.stringify({method:"worker/EVENT/UserConnect",data:{id:ws.profile.id}}))

}
// module.exports._auth = function(ws,data){
//     if (global.USERS[data.data['device']]){
//         data.data.status = 1
//     }
//     return data
// }
