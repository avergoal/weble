const request = require('request');
const execPhp = require('exec-php');
const querystring = require('querystring');
module.exports = function(data){
        switch (global.config['request']) {
            case 'local':
                setLocalRequest.bind(this)(data)
                break;
            case 'post':
                setPostRequest.bind(this)(data)
                break;
            default:
                setPostRequest.bind(this)(data)
                break;
        }
}
function setLocalRequest(data){
    let message = JSON.parse(data)
    execPhp(global.config['php_url'],'/usr/bin/php73', (error, php, outprint)=>{
    // execPhp('index.php', (error, php, outprint)=>{
        let m = message.method.split('.')
        if (global.controllers.hasOwnProperty(m[0])&&global.controllers[m[0]].hasOwnProperty("_"+m[1])){
            message = global.controllers[m[0]]["_"+m[1]](this,message)
        }
      php.proxy_function(message, (err, result, output, printed)=>{
          if (result){
              let response = JSON.parse(result);


              if (global.controllers.hasOwnProperty(m[0])&&global.controllers[m[0]].hasOwnProperty(m[1])){
                  global.controllers[m[0]][m[1]](this,{...message,...{response:response}})
              }
              if (message.method==="users.auth"){
                  message.online = getOnlineIds()
              }

              this.send(JSON.stringify({...message,data:response}));
          }
      });
    });
}
function setPostRequest(data){
    let message = JSON.parse(data)
    let m = message.method.split('.')
    if (global.controllers.hasOwnProperty(m[0])&&global.controllers[m[0]].hasOwnProperty("_"+m[1])){
        message = global.controllers[m[0]]["_"+m[1]](this,message)
    }
    let params = querystring.stringify(message.data);

    request.post({
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        url: "https://weble.club/api/",
        json: true,
        body: params
    }, (error, response, body)=>{
        if (body){

            if (global.controllers.hasOwnProperty(m[0])&&global.controllers[m[0]].hasOwnProperty(m[1])){
                global.controllers[m[0]][m[1]](this,{...message,...{response:body.response}})
            }
            if (message.method==="users.auth"){
                message.online = getOnlineIds()
            }
            this.send(JSON.stringify({...message,data:body.response}))
        }
        if (error){
            console.error(error)
        }

    });
}
